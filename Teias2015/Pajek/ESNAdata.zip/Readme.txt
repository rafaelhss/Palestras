The subdirectories in this folder contain all data files and auxiliary files mentioned in the book Exploratory Social Network Analysis with Pajek.

Please check the book's web site for more information:

http://vlado.fmf.uni-lj.si/pub/networks/book/